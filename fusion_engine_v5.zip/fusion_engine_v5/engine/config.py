from dataclasses import dataclass

POP_SIZE = 64
GENERATIONS = 30
ELITE_KEEP = 16

OPENMC_BATCHES = 80
OPENMC_PARTICLES = 300000

MC_SAMPLES = 300000
VALIDATION_TOP_N = 5

YZ_HALF = 5.0
N_MESH_X = 160
SOURCE_ENERGY_EV = 14.1e6

ENERGY_BINS = [0.0, 1.0e3, 1.0e5, 1.0e6, 5.0e6, 10.0e6, 14.2e6, 20.0e6]

@dataclass(frozen=True)
class PhysicalConstants:
    e_charge: float = 1.602176634e-19
    eps0: float = 8.8541878128e-12
    mu0: float = 4.0e-7 * 3.141592653589793
    me: float = 9.1093837015e-31
    mi_dt: float = 2.5 * 1.66053906660e-27
    mev_j: float = 1.602176634e-13

CONSTS = PhysicalConstants()
