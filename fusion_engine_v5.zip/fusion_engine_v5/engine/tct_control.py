import math
import numpy as np
from .config import CONSTS

def current_sheet_thickness(B_T, n_m3, Te_keV):
    wpe = math.sqrt((n_m3 * CONSTS.e_charge**2) / (CONSTS.me * CONSTS.eps0))
    de = 3e8 / max(wpe, 1e-9)
    beta = (2.0 * n_m3 * Te_keV * 1e3 * CONSTS.e_charge) / max(B_T**2 / (2.0 * CONSTS.mu0), 1e-12)
    return de * (1.0 + beta)

def alfven_speed(B_T, n_m3):
    return B_T / math.sqrt(max(CONSTS.mu0 * n_m3 * CONSTS.mi_dt, 1e-18))

def plasmoid_growth_rate(B_T, n_m3, delta_m):
    return alfven_speed(B_T, n_m3) / max(delta_m, 1e-9)

def tct_control_strength(risk_R, risk_H, reconn_trigger, conf_trigger):
    x = max(risk_R - reconn_trigger, risk_H - conf_trigger)
    return 1.0 / (1.0 + math.exp(-10.0 * x))

def tct_stability_metric(B_T, n_m3, Te_keV, control_strength):
    delta = current_sheet_thickness(B_T, n_m3, Te_keV)
    gamma0 = plasmoid_growth_rate(B_T, n_m3, delta)
    gamma_eff = gamma0 * (1.0 - 0.85 * control_strength)
    stability = 1.0 / (1.0 + gamma_eff / 1.0e8)
    return {
        "delta_m": delta,
        "gamma0": gamma0,
        "gamma_eff": gamma_eff,
        "stability": max(0.0, min(stability, 1.0)),
    }

def run_tct_controller(plasma, design, rng=None):
    rng = rng or np.random.default_rng()
    H_mult = rng.uniform(0.65, 1.05)
    R_mult = rng.uniform(1.0, 2.5)
    risk_R = (R_mult - 1.0) / 1.5
    risk_H = (1.05 - H_mult) / 0.4
    ctrl = tct_control_strength(risk_R, risk_H, design["reconn_trigger"], design["conf_trigger"])
    stability = tct_stability_metric(plasma["B0_T"], plasma["ne_m3"], plasma["Te_keV"], ctrl)
    return {
        "engaged": ctrl > 0.05,
        "control_strength": ctrl,
        "risk_R": risk_R,
        "risk_H": risk_H,
        "stability": stability,
    }
