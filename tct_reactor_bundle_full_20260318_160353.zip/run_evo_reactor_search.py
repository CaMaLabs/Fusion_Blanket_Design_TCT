import csv
import json
import math
import os
import random
import multiprocessing as mp
from copy import deepcopy
from pathlib import Path

mp.set_start_method("spawn", force=True)

from fusion_engine_v5.optimizer.genome import random_design
from fusion_engine_v5.engine.reactor_simulation import simulate_reactor

OUTDIR = Path("evo_reactor_runs")
OUTDIR.mkdir(exist_ok=True)

POP_SIZE = 48
GENERATIONS = 30
ELITES = 12
RANDOM_INJECT = 12
MUTATION_RATE = 0.45
MUTATION_SCALE = 0.25
SEED = 1337
WORKERS = max(1, (os.cpu_count() or 2) - 1)

random.seed(SEED)

BOUNDS = {
    "R": (4.0, 12.0),
    "a": (1.2, 2.8),
    "kappa": (1.4, 2.6),
    "B0": (4.0, 9.5),
    "Ip": (8.0, 30.0),
    "Ti": (8.0, 40.0),
    "Te": (6.0, 30.0),
    "H98": (0.85, 1.5),
    "fG": (0.35, 1.0),
    "frac_cap": (0.05, 0.95),
    "lithium_thickness": (0.0005, 0.03),
    "blanket_thickness": (0.4, 1.6),
    "lithium_velocity": (0.2, 6.0),
    "mc_samples": (50000, 300000),
}

OBJECTIVES = {
    # maximize
    "net_electric": "max",
    "bootstrap": "max",
    "TBR": "max",
    # minimize
    "wall_load": "min",
    "capex_billion": "min",
    "R": "min",
    "B0": "min",
}

HARD_LIMITS = {
    "TBR_min": 1.10,
    "wall_load_max": 8.5,
    "capex_max": 40.0,
    "net_electric_min": 500.0,
}


def clamp_value(key, value):
    if key not in BOUNDS:
        return value
    lo, hi = BOUNDS[key]
    if key == "mc_samples":
        return int(max(lo, min(hi, int(value))))
    return max(lo, min(hi, float(value)))


def sanitize_design(d):
    out = deepcopy(d)
    for k, v in list(out.items()):
        if isinstance(v, (int, float)):
            if math.isnan(v) or math.isinf(v):
                v = random_design().get(k, 1.0)
            out[k] = clamp_value(k, v)
    return out


def crossover(a, b):
    child = {}
    keys = set(a.keys()) | set(b.keys())
    for k in keys:
        av = a.get(k)
        bv = b.get(k)
        if isinstance(av, (int, float)) and isinstance(bv, (int, float)):
            t = random.random()
            val = av * t + bv * (1.0 - t)
            child[k] = clamp_value(k, val)
        else:
            child[k] = deepcopy(av if random.random() < 0.5 else bv)
    return sanitize_design(child)


def mutate(d, mutation_scale=MUTATION_SCALE):
    child = deepcopy(d)

    for k, v in list(child.items()):
        if not isinstance(v, (int, float)):
            continue
        if random.random() > MUTATION_RATE:
            continue

        if k in BOUNDS:
            lo, hi = BOUNDS[k]
            span = hi - lo
            sigma = mutation_scale * span
            nv = float(v) + random.gauss(0.0, sigma)
            child[k] = clamp_value(k, nv)
        else:
            scale = max(abs(float(v)), 1.0)
            nv = float(v) + random.gauss(0.0, mutation_scale * scale)
            child[k] = nv

    # directed mutation toward coupled regime discovery
    if "lithium_thickness" in child and random.random() < 0.40:
        child["lithium_thickness"] = clamp_value(
            "lithium_thickness",
            child["lithium_thickness"] + abs(random.gauss(0.002, 0.004)),
        )

    if "lithium_velocity" in child and random.random() < 0.30:
        child["lithium_velocity"] = clamp_value(
            "lithium_velocity",
            child["lithium_velocity"] + abs(random.gauss(0.3, 0.8)),
        )

    if "B0" in child and random.random() < 0.25:
        child["B0"] = clamp_value(
            "B0",
            child["B0"] + abs(random.gauss(0.15, 0.35)),
        )

    if "R" in child and random.random() < 0.25:
        child["R"] = clamp_value(
            "R",
            child["R"] - abs(random.gauss(0.15, 0.35)),
        )

    if "blanket_thickness" in child and random.random() < 0.30:
        child["blanket_thickness"] = clamp_value(
            "blanket_thickness",
            child["blanket_thickness"] + abs(random.gauss(0.08, 0.20)),
        )

    return sanitize_design(child)


def evaluate(d):
    d = sanitize_design(d)
    try:
        r = simulate_reactor(d)
        result = {
            "ok": True,
            "design": d,
            "result": r,
            "score": float(r.get("score", -1e18)),
        }
    except Exception as e:
        result = {
            "ok": False,
            "design": d,
            "result": {"error": str(e)},
            "score": -1e18,
        }

    result["feasible"] = is_feasible(result)
    result["objectives"] = extract_objectives(result)
    return result


def is_feasible(item):
    if not item.get("ok", False):
        return False
    r = item["result"]
    try:
        if float(r.get("TBR", -1e9)) < HARD_LIMITS["TBR_min"]:
            return False
        if float(r.get("wall_load", 1e9)) > HARD_LIMITS["wall_load_max"]:
            return False
        if float(r.get("capex_billion", 1e9)) > HARD_LIMITS["capex_max"]:
            return False
        if float(r.get("net_electric", -1e9)) < HARD_LIMITS["net_electric_min"]:
            return False
    except Exception:
        return False
    return True


def extract_objectives(item):
    d = item["design"]
    r = item["result"]
    return {
        "net_electric": float(r.get("net_electric", -1e18)),
        "bootstrap": float(r.get("bootstrap", -1e18)),
        "TBR": float(r.get("TBR", -1e18)),
        "wall_load": float(r.get("wall_load", 1e18)),
        "capex_billion": float(r.get("capex_billion", 1e18)),
        "R": float(d.get("R", 1e18)),
        "B0": float(d.get("B0", 1e18)),
    }


def dominates(a, b):
    if a["feasible"] and not b["feasible"]:
        return True
    if not a["feasible"] and b["feasible"]:
        return False

    ao = a["objectives"]
    bo = b["objectives"]

    better_or_equal = True
    strictly_better = False

    for key, direction in OBJECTIVES.items():
        av = ao[key]
        bv = bo[key]
        if direction == "max":
            if av < bv:
                better_or_equal = False
                break
            if av > bv:
                strictly_better = True
        else:  # min
            if av > bv:
                better_or_equal = False
                break
            if av < bv:
                strictly_better = True

    return better_or_equal and strictly_better


def non_dominated_sort(population):
    fronts = []
    S = {}
    n = {}
    first_front = []

    for i, p in enumerate(population):
        S[i] = []
        n[i] = 0
        for j, q in enumerate(population):
            if i == j:
                continue
            if dominates(p, q):
                S[i].append(j)
            elif dominates(q, p):
                n[i] += 1
        if n[i] == 0:
            p["rank"] = 0
            first_front.append(i)

    current = first_front
    rank = 0
    while current:
        fronts.append(current)
        next_front = []
        for i in current:
            for j in S[i]:
                n[j] -= 1
                if n[j] == 0:
                    population[j]["rank"] = rank + 1
                    next_front.append(j)
        rank += 1
        current = next_front

    return fronts


def crowding_distance(population, front_indices):
    if not front_indices:
        return
    for i in front_indices:
        population[i]["crowding"] = 0.0

    if len(front_indices) <= 2:
        for i in front_indices:
            population[i]["crowding"] = float("inf")
        return

    for key, direction in OBJECTIVES.items():
        sorted_idx = sorted(front_indices, key=lambda i: population[i]["objectives"][key])
        population[sorted_idx[0]]["crowding"] = float("inf")
        population[sorted_idx[-1]]["crowding"] = float("inf")

        min_val = population[sorted_idx[0]]["objectives"][key]
        max_val = population[sorted_idx[-1]]["objectives"][key]
        denom = max(max_val - min_val, 1e-12)

        for k in range(1, len(sorted_idx) - 1):
            i_prev = sorted_idx[k - 1]
            i_curr = sorted_idx[k]
            i_next = sorted_idx[k + 1]
            prev_v = population[i_prev]["objectives"][key]
            next_v = population[i_next]["objectives"][key]
            population[i_curr]["crowding"] += (next_v - prev_v) / denom


def pareto_select(population, target_size):
    fronts = non_dominated_sort(population)
    selected = []

    for front in fronts:
        crowding_distance(population, front)
        front_items = [population[i] for i in front]
        if len(selected) + len(front_items) <= target_size:
            selected.extend(front_items)
        else:
            front_items.sort(key=lambda x: x.get("crowding", 0.0), reverse=True)
            remaining = target_size - len(selected)
            selected.extend(front_items[:remaining])
            break

    return selected


def tournament(pop, k=4):
    picks = random.sample(pop, k=min(k, len(pop)))
    picks.sort(key=lambda x: (x.get("rank", 1e9), -x.get("crowding", 0.0)))
    return picks[0]


def save_generation(gen, ranked):
    gen_dir = OUTDIR / f"gen_{gen:03d}"
    gen_dir.mkdir(exist_ok=True)

    for i, item in enumerate(ranked[:10], 1):
        with open(gen_dir / f"reactor_{i:02d}.json", "w") as f:
            json.dump(item, f, indent=2)

    pareto_items = [x for x in ranked if x.get("rank", 9999) == 0]
    with open(gen_dir / "pareto_front.json", "w") as f:
        json.dump(pareto_items, f, indent=2)

    rows = []
    for i, item in enumerate(ranked[:25], 1):
        row = {
            "rank_order": i,
            "pareto_rank": item.get("rank"),
            "crowding": item.get("crowding"),
            "score": item.get("score"),
            "ok": item.get("ok"),
            "feasible": item.get("feasible"),
        }
        row.update(
            {
                f"design_{k}": v
                for k, v in item["design"].items()
                if isinstance(v, (int, float, str, bool))
            }
        )
        if isinstance(item["result"], dict):
            row.update(
                {
                    f"result_{k}": v
                    for k, v in item["result"].items()
                    if isinstance(v, (int, float, str, bool))
                }
            )
        rows.append(row)

    if rows:
        with open(gen_dir / "leaderboard.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)


def log_summary(gen, ranked):
    best_score = max(ranked, key=lambda x: x.get("score", -1e18))
    pareto_front = [x for x in ranked if x.get("rank", 9999) == 0]
    best_power = max(ranked, key=lambda x: x["objectives"]["net_electric"])
    best_low_capex = min(
        [x for x in ranked if x.get("feasible")],
        key=lambda x: x["objectives"]["capex_billion"],
        default=min(ranked, key=lambda x: x["objectives"]["capex_billion"]),
    )

    b = best_score
    print(
        f"GEN {gen:03d} | "
        f"front={len(pareto_front)} | "
        f"bestScore={b.get('score', None):.3f} | "
        f"P={b['result'].get('net_electric', None)} | "
        f"WL={b['result'].get('wall_load', None)} | "
        f"TBR={b['result'].get('TBR', None)} | "
        f"BS={b['result'].get('bootstrap', None)} | "
        f"CAPEX={b['result'].get('capex_billion', None)} | "
        f"R={b['design'].get('R', None)} "
        f"B0={b['design'].get('B0', None)} "
        f"lt={b['design'].get('lithium_thickness', None)} "
        f"bt={b['design'].get('blanket_thickness', None)}"
    )

    print(
        f"  Pareto-best-power: P={best_power['result'].get('net_electric', None)} "
        f"WL={best_power['result'].get('wall_load', None)} "
        f"TBR={best_power['result'].get('TBR', None)} "
        f"CAPEX={best_power['result'].get('capex_billion', None)} "
        f"R={best_power['design'].get('R', None)} "
        f"B0={best_power['design'].get('B0', None)}"
    )

    print(
        f"  Pareto-low-capex: P={best_low_capex['result'].get('net_electric', None)} "
        f"WL={best_low_capex['result'].get('wall_load', None)} "
        f"TBR={best_low_capex['result'].get('TBR', None)} "
        f"CAPEX={best_low_capex['result'].get('capex_billion', None)} "
        f"R={best_low_capex['design'].get('R', None)} "
        f"B0={best_low_capex['design'].get('B0', None)}"
    )


def main():
    mutation_scale = MUTATION_SCALE
    population = [sanitize_design(random_design()) for _ in range(POP_SIZE)]
    history = []

    for gen in range(GENERATIONS):
        if gen > 0 and gen % 10 == 0:
            mutation_scale = min(mutation_scale * 1.15, 0.6)

        with mp.Pool(WORKERS) as pool:
            evaluated = pool.map(evaluate, population)

        selected = pareto_select(evaluated, len(evaluated))
        selected.sort(key=lambda x: (x.get("rank", 1e9), -x.get("crowding", 0.0), -x.get("score", -1e18)))

        best_score = max(selected, key=lambda x: x.get("score", -1e18))
        pareto_front = [x for x in selected if x.get("rank", 9999) == 0]

        history.append(
            {
                "generation": gen,
                "front_size": len(pareto_front),
                "best_score": best_score["score"],
                "net_electric": best_score["result"].get("net_electric"),
                "wall_load": best_score["result"].get("wall_load"),
                "raw_wall_load": best_score["result"].get("raw_wall_load"),
                "bootstrap": best_score["result"].get("bootstrap"),
                "TBR": best_score["result"].get("TBR"),
                "capex_billion": best_score["result"].get("capex_billion"),
                "R": best_score["design"].get("R"),
                "B0": best_score["design"].get("B0"),
                "lithium_thickness": best_score["design"].get("lithium_thickness"),
                "blanket_thickness": best_score["design"].get("blanket_thickness"),
                "mutation_scale": mutation_scale,
            }
        )

        log_summary(gen, selected)
        save_generation(gen, selected)

        elites = [deepcopy(x["design"]) for x in selected[:ELITES]]
        front_designs = [deepcopy(x["design"]) for x in pareto_front[:max(4, min(12, len(pareto_front)))]]

        new_population = []
        new_population.extend(elites)
        new_population.extend(front_designs)

        for _ in range(RANDOM_INJECT):
            new_population.append(sanitize_design(random_design()))

        breeding_pool = selected[:max(20, len(selected) // 2)]

        while len(new_population) < POP_SIZE:
            p1 = tournament(breeding_pool)["design"]
            p2 = tournament(breeding_pool)["design"]
            child = crossover(p1, p2)
            child = mutate(child, mutation_scale)
            new_population.append(child)

        population = new_population[:POP_SIZE]

    with open(OUTDIR / "history.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=history[0].keys())
        writer.writeheader()
        writer.writerows(history)

    all_front = []
    for gen_dir in sorted(OUTDIR.glob("gen_*")):
        fp = gen_dir / "pareto_front.json"
        if fp.exists():
            with open(fp) as f:
                all_front.extend(json.load(f))

    # dedupe approximate duplicates by rounded core metrics
    seen = set()
    unique_front = []
    for item in all_front:
        r = item.get("result", {})
        d = item.get("design", {})
        key = (
            round(float(r.get("net_electric", -9999)), 1),
            round(float(r.get("wall_load", 9999)), 3),
            round(float(r.get("TBR", -9999)), 3),
            round(float(r.get("capex_billion", 9999)), 3),
            round(float(d.get("R", 9999)), 3),
            round(float(d.get("B0", 9999)), 3),
        )
        if key not in seen:
            seen.add(key)
            unique_front.append(item)

    # rank combined front again
    for item in unique_front:
        item["feasible"] = is_feasible(item)
        item["objectives"] = extract_objectives(item)
    combined = pareto_select(unique_front, len(unique_front))
    combined.sort(key=lambda x: (x.get("rank", 1e9), -x.get("crowding", 0.0), -x.get("score", -1e18)))

    with open(OUTDIR / "pareto_front.json", "w") as f:
        json.dump([x for x in combined if x.get("rank", 9999) == 0], f, indent=2)

    if combined:
        best_score = max(combined, key=lambda x: x.get("score", -1e18))
        with open(OUTDIR / "best_overall.json", "w") as f:
            json.dump(best_score, f, indent=2)

    print(f"\nDone. Outputs in: {OUTDIR}")


if __name__ == "__main__":
    main()
