"""Run the pre-crossing core-effect matrix."""
from concurrent.futures import ThreadPoolExecutor
import os
import subprocess
import sys

from run import LEVELS, ROOT


def execute(job):
    level, group = job
    subprocess.run(
        [sys.executable, str(ROOT/"run.py"), level, group],
        env={**os.environ, "OPENBLAS_NUM_THREADS": "1"}, check=True,
    )


if __name__ == "__main__":
    levels = sys.argv[1:] or LEVELS
    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(execute, ((level, group) for level in levels
                                for group in ("baseline", "fixed", "motion"))))
