# TCT spherical core effect before the X-point crossing

This experiment isolates the mechanical effect of the spherical core in the local 3D resistive MHD model. The original flow perturbation, volume-penalized sphere, and trajectory are carried over from the sheet-width replay. The core field is disabled. The ambient magnetic configuration is retained. Time, length, and current use the original model's normalized units. The reference trajectory would cross the X-point at time 1.00. This experiment follows the approach from time 0.00 to 0.60. [Previous current-sheet replay](https://chatgpt.com/library?file_id=libfile_2e974a8c732881919ac3b3abfa21ede8&account_id=personal)

| Case | Prescribed motion |
|---|---|
| Baseline | No core |
| Fixed | Same sphere held at y = 0.4000 from the start |
| Fixed at stop | Same sphere held at y = 0.37916 from the start on the archive and fine meshes |
| Moving | Same archived approach |
| Hold | Same approach through time 0.25, then smooth braking to zero speed at time 0.35 and y = 0.37916 |

The braking trajectory matches position, velocity, and acceleration at the branch and stops with zero acceleration. The moving and hold trajectories share a single model state through time 0.25. The four primary cases run on 64 × 52 × 52 with a time step of 0.00625, and on 96 × 80 × 80 with time steps of 0.00625 and 0.003125. All outputs are sampled at a common interval of 0.0125. The archive-mesh baseline and moving-core measurements reproduce the previous report exactly at all 13 shared sampling times.

## Results

The archived approach clears both targets at four consecutive samples from time 0.2875 to 0.3250. The brake-and-hold trajectory clears both at 20 consecutive samples from time 0.2875 to 0.5250. That sequence includes 15 passing samples at or after zero speed at time 0.3500. The narrowest adjusted mean width gain over those 20 samples is +0.919%, and the largest adjusted peak-current increase is +0.0571%. Independently, the median width containing the central 50% of current increases by +0.081% to +0.494% throughout those samples on the finest run.

At time 0.50, the braking case still has +5.20% mean half-maximum width, +0.45% median current-integral width, and −0.42% peak sampled current relative to the baseline on the fine mesh with the half time step. The continuing approach has +84.82% peak sampled current at that time. The stationary control at the same stopping point produces −0.11% and −0.078% mean half-maximum width changes on the archive and fine meshes. The comparison supports the effect of the motion history in this model. The fixed sphere at the original starting point also has zero joint passes.

The gain magnitude varies with spatial resolution. At the finest setting the stopping case stays below the current cap at more raw samples than the numerical screen confirms. The window above ends at the last continuously passing sample after accounting for the measured resolution sensitivity.

## Measures and thresholds

The half-maximum width follows the local sheet ridge and is evaluated along its estimated normal. A second measure takes the distance from the 25th to the 75th percentile of cumulative positive current inside a fixed interval of ±0.42 about the ridge. Treatment and reference widths are compared at common stations. The report includes both the mean absolute-width ratio and the median of the station-by-station ratios.

The current cap now uses a separate scan of the signed sheet current across the whole diagnostic annulus. For each frame it samples 1,460 positions parallel to the original sheet at radii 0.32 to 0.75 around the trajectory axis, and 161 positions across the original sheet from y = −0.40 to +0.40, then refines the local peak in y by quadratic interpolation. The annulus sits outside the smoothed core mask for all trajectories. The peak stays available when a half-maximum profile is ambiguous. The cap applies to the sampled annulus.

A sample clears the previous local screen with complete coverage at all 36 half-maximum stations, a mean half-maximum width gain above +0.020%, and a peak current increase of at most +0.100%. The comparison subtracts the measured mesh and time-step sensitivity from the width gain and adds it to the current increase. A manufactured-translation error allowance is also subtracted from the width gain. These allowances summarize the tested settings and do not bound the continuum result. A contiguous sequence of passing samples describes a resolved interval at the chosen output cadence.

The experiment uses normalized, prescribed motion. Model results do not establish actuator authority, achievable steering, full-tokamak behavior, or the solid core's survival.

## Reproduce

Run from the unpacked directory using Python 3, NumPy 2.x, SciPy, and Matplotlib.

```bash
python3 matrix.py
OPENBLAS_NUM_THREADS=1 python3 run.py archive_mesh fixed_near
OPENBLAS_NUM_THREADS=1 python3 run.py fine_mesh fixed_near
OPENBLAS_NUM_THREADS=1 python3 analyze.py
```
