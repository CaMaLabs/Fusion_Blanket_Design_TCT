# Bidirectional TCT core orbit and disturbance screen

The half-mass probe with angular-momentum and height-priority guidance completed all compounded launches at the tested angles and in both directions. The loaded probe used a bare ratio of 5,000 A·m²/kg, a 5% shell mass increment and a nominal launch speed of 85.82 m/s. A three-lap pass includes two laps of travel after the kick.

| Bare moment-to-mass ratio (A·m²/kg) | Load at nominal speed | Compound passes | Worst clearance |
| ---: | --- | ---: | ---: |
| 4,000 | 5% mass, 0.0002 T/m | 10/16 | −0.047 mm |
| 5,000 | 5% mass, 0.0002 T/m | 16/16 | +9.790 mm |
| 5,000 | 5% mass, speed-scaled drag with fixed area, 0.0004002 T/m | 16/16 | +10.321 mm |
| 5,000 | 5% mass, speed-scaled drag with smaller area, 0.0002521 T/m | 16/16 | +9.971 mm |

The original guidance at 5,000 A·m²/kg passed the bare kick in 8/8 trials. The loaded probe with that guidance exited the corridor after the kick in 8/8 trials. The 4% drag reduction changed none of the original-guidance pass or fail verdicts at the tested ratios. At 2,500 A·m²/kg, the new guidance passed the two separate combined launch errors, with 8/8 for each loaded pattern. The loaded fast-high launches began at the vertical limit and the loaded kick exited in 8/8 trials. All 112 matched bidirectional control cases and all 144 matched mass-and-guidance cases retained their pass or fail verdict under field and step refinement.

The core is a point dipole in the archived DIII-D shot 158103 reconstruction at 3796 ms. The dipole follows the local field direction with fixed moment. The initial bidirectional screen uses bare moment-to-mass ratios of 2,500 and 3,000 A·m²/kg. All runs use the archived outboard radius of 2.20 m and the same ±25 mm radial and vertical corridor around the unshifted reference. The controller limits each I-coil to 1.6 kA with a first-order 100 Hz response. The starting coil currents are initialized at the guidance command.

Every test starts at 0°, 90°, 180°, or 270° and runs in both toroidal directions. A pass requires completing three laps inside the corridor. Each loaded run adds inertial mass with the dipole moment held fixed and uses the lower of the ambient gravity-balanced height and the upper corridor boundary minus 1 mm. The commanded circular speed is recomputed at that height. The imposed toroidal load opposes motion, scales with the square of toroidal speed, and is specified as force per moment at the nominal speed. Guidance uses velocity feedback, with drag feedforward disabled.

The two combined launch errors both start 5 mm radially outward. The fast high case adds +1 mm vertically and +0.25% in toroidal speed magnitude. The slow low case adds −1 mm vertically and −0.25% in speed magnitude. The kick cases start at the nominal launch state and add +0.10 m/s radially outward and +0.10 m/s upward at the first integration step after one lap. Passing a kick case establishes that the simulated trajectory stayed within the corridor for the following two laps.

This screen combines prescribed drag, added mass, launch offsets and coil feedback in the orbit model. The plasma response, vessel screening, coil supply interactions and attitude dynamics are outside the calculation. The separate local MHD results use normalized units, so their loads and current-sheet gains have no established mapping to this orbit.

## Reproduce

Run from the unpacked directory with Python 3, NumPy, SciPy and Matplotlib.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 coupled_recovery.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 coupled_recovery.py --steps 576 --fine-field
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 coupled_recovery.py --steps 576 --fine-field --bare-kappa 3000 \
  bare_nominal bare_fast_high bare_slow_low bare_kick \
  shell_5pct_drag_01_fast_high shell_5pct_drag_01_slow_low shell_5pct_drag_01_kick
```

The original grid uses 144 toroidal angles, 15 points in each transverse direction and 48 chords per curved filament section. The finer grid uses 216 angles, 19 points in each transverse direction and 64 chords per curved section. The fine replay doubles the number of integration steps per nominal lap from 288 to 576. Each row records the outcome, travel, maximum offset in each transverse direction and the minimum sampled corridor margin. Negative margins indicate a corridor exit.

## Two smaller probes

At fixed density and magnetic moment per unit volume, splitting a sphere into two equal spheres preserves the bare moment-to-mass ratio. Each radius is 79.37% of the original and the combined projected area is 125.99%. A thin shell of fixed thickness also adds approximately 25.99% more shell mass to the pair. The geometric area is a sensitivity input. Drag in plasma requires its own model.

The next current-sheet comparison should use the original core, a single half-mass core, and two half-mass cores making sequential passes at matched combined mass. Sweep spacing in time while keeping the probes physically separated and compare the continuous interval of broadening that clears the same peak-current cap. Keep simultaneous flight a later test so shared-coil control and probe interactions can be evaluated with the measured single-probe response.

## Mass, shape and guidance tests

`weight_shape.py` varies the bare mass at fixed moment, with the original 2,500 A·m²/kg design as the reference. A ratio of 5,000 corresponds to half the original bare mass. Each case uses the same launch perturbations or the same impulse as the bidirectional screen. The loaded case adds 5% of the selected bare mass, plus a force per moment of 0.0002 T/m opposing toroidal travel at nominal speed. The streamlined sensitivity reduces this imposed force by 4% to 0.000192 T/m. The model still treats the probe as a point dipole. The archived MHD work difference motivated the sensitivity amount. It supplies no quantitative drag prediction in DIII-D.

The height-priority controller asks the same feedback law to favor the vertical force during coil allocation. The angular-momentum controller favors vertical force, reduces radial demand in the allocation, and regulates toroidal angular momentum instead of tangential speed. As radius oscillates, this lets speed vary with radius without requiring a tangential correction to cancel that motion. Both controllers use the same 1.6 kA limit and 100 Hz response as the original guidance.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py 2500 5000 7500 10000
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py --controller height_priority 2500 5000
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py --controller momentum 2500 5000
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py --fine \
  --controller original --controller momentum 2500 5000
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py --fine --compound \
  --controller momentum 4000 5000
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 weight_shape.py --fine --compound \
  --speed-scaled-drag --controller momentum 5000
```

The compound cases apply the kick after one lap of the perturbed launch. They use four starting angles in both directions for each launch pattern and load. These tests explore parameter values in a free-flight model. Producing the assumed moment with the lower physical mass remains a design requirement.

The speed-scaled sensitivity holds an illustrative drag coefficient fixed. Its reference drag is 0.0002 T/m at the 2,500 A·m²/kg coated probe's nominal speed. It rescales the force by the square of the new nominal speed. The smaller-area variant also scales projected area with bare mass to the two-thirds power, as for geometric scaling at fixed density. Both scenarios retain the specified magnetic moment.

- [Prior orbit, lift, drag, and shell runs](https://chatgpt.com/library?file_id=libfile_97e88f51694081919e3d12da7ba7fb1f&account_id=personal)
- [Prior local MHD approach-and-hold runs](https://chatgpt.com/library?file_id=libfile_d6bf28a0ef448191bee6078ef42d11d9&account_id=personal)
