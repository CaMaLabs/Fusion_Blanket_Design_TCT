"""Replay the archived shapes and record the fluid reaction on the core."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path

import numpy as np

import sweep_mhd as mhd


ROOT = Path(__file__).resolve().parent
LEVELS = {"screen": ((48, 40, 40), .0125), "refined": ((64, 52, 52), .0125), "fine": ((80, 64, 64), .00625)}


def replay(task):
    level, name, shape = task
    mesh, dt = LEVELS[level]
    grid = mhd.Grid(mesh, "xpoint", "sphere" if shape == "sphere" else "elongated")
    if shape == "guide_aligned":
        grid.axes[:] = grid.axes[[0, 2, 1]]
    core, field = mhd.CASES[name]
    state = np.array(mhd.initial_state(grid))
    steps = round(mhd.END / dt)
    trace = []
    reference = {}
    if level == "refined" and shape != "guide_aligned":
        prior = json.loads((ROOT / "reference" / f"{name}_xpoint_{shape}.json").read_text())
        reference = {round(row["t"] / dt): row for row in prior["records"]}
    max_delta = 0.
    for step in range(steps + 1):
        t = step * dt
        _, mask, _, speed = mhd.probe(grid, t, core, field)
        relative = -grid.physical(state[0])
        relative[1] += speed
        force = grid.volume * np.mean(mask * relative, axis=(1, 2, 3)) / mhd.PENALTY_TIME
        trace.append([t, speed, *force, force[1] * speed, grid.volume * float(mask.mean())])
        if step in reference:
            measured, _ = mhd.observe(grid, state, t, core, field)
            recorded = reference[step]
            for key in ("projected_midplane_flux_contrast", "volume_joule_power", "fluid_fraction"):
                max_delta = max(max_delta, abs(measured[key] - recorded[key]))
        if step < steps:
            initial = mhd.rhs(grid, state, t, core, field, mhd.PENALTY_TIME)
            state += dt * mhd.rhs(grid, state + dt / 2 * initial, t + dt / 2, core, field, mhd.PENALTY_TIME)
    assert np.isfinite(state).all() and max_delta < 1e-10
    data = np.array(trace)
    incoming = data[:, 0] <= mhd.END / 2
    pos = np.maximum(data[:, 5], 0.)
    result = dict(level=level, case=name, shape=shape, mesh=grid.shape, axes=grid.axes.tolist(),
                  archived_trace_max_difference=max_delta if reference else None,
                  positive_work_full=float(np.trapezoid(pos, data[:, 0])),
                  positive_work_approach=float(np.trapezoid(pos[incoming], data[incoming, 0])),
                  max_opposing_load=float(np.max(data[:, 3] * np.sign(data[:, 1]))),
                  mean_mask_volume=float(data[:, 6].mean()), records=data.tolist())
    print(level, name, shape, "approach work", result["positive_work_approach"], flush=True)
    return result


def main(fine):
    levels = ("fine",) if fine else ("screen", "refined")
    shapes = ("sphere", "elongated") if fine else ("sphere", "elongated", "guide_aligned")
    jobs = [(level, name, shape) for level in levels for name in ("core", "combined") for shape in shapes]
    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(replay, jobs))
    summary = []
    for row in rows:
        if row["shape"] == "sphere":
            continue
        base = next(r for r in rows if r["level"] == row["level"] and r["case"] == row["case"]
                    and r["shape"] == "sphere")
        metrics = ("positive_work_full", "positive_work_approach", "max_opposing_load", "mean_mask_volume")
        changes = {key: 100 * (row[key] / base[key] - 1) for key in metrics}
        summary.append(dict(level=row["level"], case=row["case"], shape=row["shape"], changes_pct=changes))
    columns = ("normalized_time", "body_speed_y", "force_on_fluid_x", "force_on_fluid_y",
               "force_on_fluid_z", "power_from_prescribed_body", "mask_volume")
    result = dict(columns=columns, from_sphere=summary, runs=rows)
    name = "shape_load_fine.json" if fine else "shape_load.json"
    (ROOT.parent / "runs" / name).write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--fine", action="store_true")
    main(args.parse_args().fine)
