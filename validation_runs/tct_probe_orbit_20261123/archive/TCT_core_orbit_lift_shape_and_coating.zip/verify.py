"""Check representative outcomes against finer field and time steps."""

import json

import numpy as np

from coil_basis import basis
from fields import FieldMap, RADIUS, ROOT, TWO_PI
from orbit import FIXED, G, I_LIMIT, propulsion, trajectory
from run import LAUNCHES, shifted_height


def direct_ring_work(model):
    samples = 360
    angles = TWO_PI * (np.arange(samples) + 0.5) / samples
    points = np.column_stack((np.full(samples, RADIUS), angles, np.full(samples, model.height)))
    h = 0.0005
    offset = np.array([0., h / RADIUS, 0.])
    wires = basis(points, 96)
    deriv = (basis(points + offset, 96) - basis(points - offset, 96)) / (2 * h)
    ambient = model.field(RADIUS, model.height)
    modes = np.fft.fftfreq(samples, d=1 / samples)[:, None]
    response = np.zeros((samples, 3, len(I_LIMIT)))
    response[:, 1] = deriv @ (ambient / np.linalg.norm(ambient))
    command = propulsion(response, I_LIMIT)
    harmonics = np.fft.fft(command, axis=0)
    output = {}
    for lap_rate in (1, 10, 100, 300):
        current = np.fft.ifft(harmonics / (1 + 1j * modes * lap_rate / 100), axis=0).real
        field = ambient + np.einsum("nij,ni->nj", wires, current)
        change = np.einsum("nij,ni->nj", deriv, current)
        gradient = np.sum(field * change, axis=1) / np.linalg.norm(field, axis=1)
        output[lap_rate] = float(gradient.mean() * TWO_PI * RADIUS)
    return output


def energy_spread(model, trace, static_currents):
    radius, _, height = trace[:, 1:4].T
    field = model.field(radius, height)
    if static_currents is not None:
        field += np.einsum("nij,i->nj", basis(trace[:, 1:4], 96), static_currents)
    energy = np.sum(trace[:, 4:]**2, axis=1) / 2 - np.linalg.norm(field, axis=1) + G / 10000 * height
    return float(np.ptp(energy))


def main():
    runs = ROOT / "runs"
    data = json.loads((runs / "results.json").read_text())
    model = FieldMap(angles=216, transverse=19, segments=64)
    direct = direct_ring_work(model)
    for row in data["ring"]["results"]:
        if row["config"] == "independent_I_1.6kA" and row["cutoff_hz"] == 100:
            reference = row["forward_work_per_moment_T"]
            assert abs(direct[row["laps_hz"]] - reference) < 0.01 * reference
    cases = []
    for coarse in data["trajectories"]:
        if (coarse["suite"] not in ("main", "gravity_balanced") or not coarse["gravity"]
                or coarse["kappa_Am2_kg"] not in (3000, 10000)
                or coarse["mode"] == "drive_1.6kA_I"
                or coarse["launch_id"] not in ("1mm_up", "1pct_fast")):
            continue
        height = shifted_height(model, coarse["kappa_Am2_kg"]) if coarse["suite"] == "gravity_balanced" else None
        row, _ = trajectory(model, coarse["mode"], coarse["kappa_Am2_kg"], True, coarse["phase_deg"],
                            LAUNCHES[coarse["launch_id"]], 100, steps_per_lap=576, balanced_height=height)
        assert (row["outcome"] == "completed") == (coarse["outcome"] == "completed"), (coarse, row)
        assert abs(row["laps"] - coarse["laps"]) < .025, (coarse, row)
        row.update(suite=coarse["suite"], launch_id=coarse["launch_id"], reference_laps=coarse["laps"])
        cases.append(row)
    traces = np.load(runs / "trajectories.npz")
    errors = {"ambient_T": energy_spread(model, traces["ambient"], None),
              "fixed_plane_original_map_T": energy_spread(model, traces["fixed_plane_5kA_IC"], FIXED)}
    _, finer_static = trajectory(model, "fixed_plane_5kA_IC", 10000, True, 90, LAUNCHES["1mm_up"], 100,
                                 steps_per_lap=576, traces=True)
    errors["fixed_plane_finer_map_T"] = energy_spread(model, finer_static, FIXED)
    assert errors["ambient_T"] < 1e-8
    assert np.ptp(traces["ambient"][:, 1] * traces["ambient"][:, 5]) < 1e-8
    assert errors["fixed_plane_finer_map_T"] < errors["fixed_plane_original_map_T"] < 4e-5
    result = dict(direct_ring_work_T=direct, energy_spread_per_moment=errors, trajectories=cases)
    (runs / "verification.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(f"Verified {len(cases)} outcomes; energy spread {errors}", flush=True)


if __name__ == "__main__":
    main()
