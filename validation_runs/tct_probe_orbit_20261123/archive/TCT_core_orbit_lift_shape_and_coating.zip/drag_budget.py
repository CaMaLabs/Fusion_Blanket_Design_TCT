"""Apply an illustrative toroidal load to the gravity-balanced orbit."""

from collections import Counter
import json

from fields import FieldMap, ROOT
from orbit import trajectory
from run import LAUNCHES, shifted_height


def main():
    model = FieldMap()
    kappa = 2500
    height = shifted_height(model, kappa)
    rows = []
    for drag in (0., 0.000025, 0.00005, 0.0001, 0.0002, 0.0004):
        for compensation in (False, True):
            group = []
            for phase in (0, 90, 180, 270):
                row, _ = trajectory(model, "guided_1.6kA_I", kappa, True, phase, LAUNCHES["nominal"],
                                    100, balanced_height=height, drag_per_moment=drag,
                                    compensate_drag=compensation)
                row.update(drag_at_launch_T_m=drag, drag_feedforward=compensation)
                group.append(row)
            print(drag, compensation, dict(Counter(r["outcome"] for r in group)), flush=True)
            rows.extend(group)
    output = dict(assumption="Opposing toroidal force proportional to squared toroidal speed through stationary fluid",
                  trajectories=rows)
    (ROOT / "runs" / "drag_budget.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
