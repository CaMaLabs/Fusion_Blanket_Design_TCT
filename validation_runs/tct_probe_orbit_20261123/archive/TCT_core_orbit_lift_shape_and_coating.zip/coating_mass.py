"""Screen added shell mass with the core moment held fixed."""

from collections import Counter
import json

from fields import FieldMap, HALF_WIDTH, RADIUS, ROOT
from orbit import G, trajectory
from run import shifted_height


def main():
    model = FieldMap()
    bare_ratio = 2500.
    pad = .001
    max_height = model.height + HALF_WIDTH
    target_cap = max_height - pad
    passive_mass_limit = bare_ratio * model.ambient(RADIUS, max_height)[1][2] / G - 1
    passive_mass_limit_with_pad = bare_ratio * model.ambient(RADIUS, target_cap)[1][2] / G - 1
    runs = []
    for added in (0., .025, .05, .075, .10, .20):
        ratio = bare_ratio / (1 + added)
        trim = shifted_height(model, ratio)
        target = target_cap if trim is None else min(trim, target_cap)
        tests = []
        for phase in (0, 90, 180, 270):
            for initial_height in (-pad, 0., pad):
                row, _ = trajectory(model, "guided_1.6kA_I", ratio, True, phase, (0., initial_height, 1.),
                                    100, balanced_height=target)
                tests.append(row)
        counts = Counter(row["outcome"] for row in tests)
        print(f"Added mass fraction {added:.3f}: {dict(counts)}", flush=True)
        runs.append(dict(added_mass_fraction=added, kappa_Am2_kg=ratio, ambient_trim_height_m=trim,
                         test_height_m=target, outcomes=dict(counts), trajectories=tests))
    note = "Additional mass only. Moment, drag, footprint and thermal and plasma properties held fixed."
    output = dict(assumption=note, extra_mass_limit_for_passive_trim=passive_mass_limit,
                  extra_mass_limit_for_passive_trim_with_1mm_margin=passive_mass_limit_with_pad, groups=runs)
    (ROOT / "runs/coating_mass.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
