"""Test prescribed on-core dipole orientation against the reconstructed field."""

import json

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

from equilibrium import read_geqdsk
from fields import HALF_WIDTH, RADIUS, ROOT, TWO_PI
from orbit import G


def geometry(field, gradient, radius, height):
    magnetic = field(radius, height)
    jac = gradient(radius, height)
    # The cylindrical basis rotates in phi. The term drops out for an aligned
    # dipole and contributes to the force when the core tilts off the field.
    jac[1] = np.array([-magnetic[1], magnetic[0], 0.]) / radius
    unit = magnetic / np.linalg.norm(magnetic)
    lift = jac[2] - (jac[2] @ unit) * unit
    tangential = jac[1]
    neutral = lift - (lift @ tangential) / (tangential @ tangential) * tangential
    return magnetic, jac, unit, lift / np.linalg.norm(lift), neutral / np.linalg.norm(neutral)


def command(model, mode, radius, height, target, ceiling):
    magnetic, jac, direction, lift, neutral = geometry(*model, radius, height)
    direction2 = neutral if mode == "tangential_neutral" else lift
    ambient, leverage = jac[2] @ direction, jac[2] @ direction2
    if mode == "aligned":
        angle = 0.
    else:
        value = np.clip(target / np.hypot(leverage, ambient), -1, 1)
        angle = np.clip(np.arcsin(value) - np.arctan2(ambient, leverage), -ceiling, ceiling)
    moment = direction * np.cos(angle) + direction2 * np.sin(angle)
    force = jac @ moment
    torque = np.cross(moment, magnetic)
    assert abs(radius * force[1] + torque[2]) < 1e-13
    return force, torque, float(angle)


def flight(model, z0, kappa, mode, limit_deg, offset, speed_error):
    gravity = G / kappa
    ceiling = np.deg2rad(limit_deg)
    steady, steady_torque, steady_angle = command(model, mode, RADIUS, z0, gravity, ceiling)
    speed = np.sqrt(-RADIUS * steady[0])
    duration = TWO_PI * RADIUS / speed
    controls = []

    def rate(_, state):
        radius, phi, height, vr, vt, vz = state[:6]
        target = gravity - 0.50 * (height - z0) - 0.80 * vz
        force, torque, angle = command(model, mode, radius, height, target, ceiling)
        controls.append((angle, np.linalg.norm(torque)))
        c, s = np.cos(phi), np.sin(phi)
        torque_xyz = np.array([c * torque[0] - s * torque[1], s * torque[0] + c * torque[1], torque[2]])
        return np.r_[vr, vt / radius, vz, force[0] + vt**2 / radius,
                     force[1] - vr * vt / radius, force[2] - gravity, torque_xyz / np.sqrt(kappa)]

    def corridor(_, state):
        return HALF_WIDTH - max(abs(state[0] - RADIUS), abs(state[2] - z0))

    def three_laps(_, state):
        return 3 * TWO_PI - state[1]

    corridor.terminal = three_laps.terminal = True
    corridor.direction = three_laps.direction = -1
    initial = [RADIUS, 0., z0 + offset, 0., speed * (1 + speed_error), 0., 0., 0., 0.]
    result = solve_ivp(rate, (0., duration * 4), initial, events=(corridor, three_laps),
                       rtol=2e-8, atol=1e-10, max_step=duration / 240)
    assert result.success
    return dict(kappa_Am2_kg=kappa, mode=mode, tilt_limit_deg=limit_deg, launch_height_error_m=offset,
                speed_error=speed_error, launch_speed_m_s=initial[4] * np.sqrt(kappa),
                outcome="completed" if len(result.t_events[1]) else "corridor_or_time_limit",
                laps=float(result.y[1, -1] / TWO_PI), final_time_s=float(result.t[-1] / np.sqrt(kappa)),
                peak_tilt_deg=float(np.rad2deg(np.abs(np.array(controls)[:, 0]).max())),
                peak_torque_per_moment_T=float(np.array(controls)[:, 1].max()),
                peak_external_angular_impulse_per_mass_m2_s=float(kappa * np.linalg.norm(result.y[6:], axis=0).max()),
                nominal_tilt_deg=float(np.rad2deg(steady_angle)), nominal_torque_xyz_local=steady_torque.tolist(),
                nominal_force_per_moment_T_m=steady.tolist())


def main():
    _, _, _, _, field, gradient = read_geqdsk(ROOT / "reference/g158103.03796")
    z0 = brentq(lambda z: gradient(RADIUS, z)[2] @ field(RADIUS, z), -.04, .01)
    model = field, gradient
    ambient = geometry(*model, RADIUS, z0)
    static = []
    cases = []
    for kappa in (2500, 10000):
        for mode in ("maximum_vertical", "tangential_neutral"):
            force, torque, angle = command(model, mode, RADIUS, z0, G / kappa, np.pi / 2)
            static.append(dict(kappa_Am2_kg=kappa, mode=mode, angle_deg=float(np.rad2deg(angle)),
                               force_per_moment_T_m=force.tolist(), torque_per_moment_T=float(np.linalg.norm(torque)),
                               torque_per_mass_Nm_kg=float(kappa * np.linalg.norm(torque))))
        configs = [("aligned", 0.), ("maximum_vertical", 1.), ("tangential_neutral", 1.),
                   ("tangential_neutral", 2.), ("tangential_neutral", 8.), ("tangential_neutral", 10.)]
        for mode, cap in configs:
            for offset, speed in ((0., 0.), (.001, 0.), (-.001, 0.), (0., .0025), (0., -.0025)):
                cases.append(flight(model, z0, kappa, mode, cap, offset, speed))
    out = dict(radius_m=RADIUS, height_m=z0, ambient_field_T=ambient[0].tolist(),
               jacobian_T_m=ambient[1].tolist(), static=static, controlled_trajectories=cases)
    (ROOT / "runs" / "core_lift.json").write_text(json.dumps(out, indent=2, allow_nan=False) + "\n")
    for row in static:
        print(row, flush=True)
    for kappa in (2500, 10000):
        for m, deg in configs:
            selected = [row for row in cases if (row["kappa_Am2_kg"], row["mode"], row["tilt_limit_deg"]) == (kappa, m, deg)]
            print(kappa, m, deg, sum(r["outcome"] == "completed" for r in selected), "of", len(selected), flush=True)


if __name__ == "__main__":
    main()
