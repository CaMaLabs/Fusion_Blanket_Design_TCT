"""Probe the moment-to-mass threshold for vertical support at the fixed height."""

from collections import Counter
import json

from fields import FieldMap, ROOT
from orbit import G, trajectory
from run import LAUNCHES, reference


def main():
    model = FieldMap()
    authority = reference(model)["vertical_authority_linear_T_m"]["I_1.6kA"]
    threshold = G / authority[0]
    results = []
    for kappa in (10000, 18000, 20000, 30000, 50000):
        for phase in (0, 90, 180, 270):
            for launch in ("nominal", "1mm_up", "1mm_down"):
                row, _ = trajectory(model, "guided_1.6kA_I", kappa, True, phase, LAUNCHES[launch], 100)
                row["launch_id"] = launch
                results.append(row)
        counts = Counter(r["outcome"] for r in results if r["kappa_Am2_kg"] == kappa)
        print(f"Fixed-height support at kappa={kappa}: {dict(counts)}", flush=True)
    refined = []
    for kappa in (20000, 30000, 50000):
        for launch in ("nominal", "1mm_down"):
            row, _ = trajectory(model, "guided_1.6kA_I", kappa, True, 90, LAUNCHES[launch], 100,
                                steps_per_lap=576)
            reference_case = next(r for r in results if r["kappa_Am2_kg"] == kappa and r["phase_deg"] == 90
                                  and r["launch_id"] == launch)
            assert (row["outcome"] == "completed") == (reference_case["outcome"] == "completed")
            assert abs(row["laps"] - reference_case["laps"]) < .01
            row["launch_id"] = launch
            refined.append(row)
    destination = ROOT / "runs"
    destination.mkdir(exist_ok=True)
    output = dict(first_order_kappa_for_pointwise_vertical_support_Am2_kg=threshold,
                  independent_I_coil_vertical_range_T_m=authority, trajectories=results,
                  half_step=refined)
    (destination / "support_margin.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
