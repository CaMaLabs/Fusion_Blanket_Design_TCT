"""Check phase robustness after shifting the orbit height to balance gravity."""

from collections import Counter
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from fields import FieldMap, ROOT
from orbit import trajectory
from run import shifted_height


LAUNCHES = {
    "nominal": (0., 0., 1.),
    "1mm_up": (0., .001, 1.),
    "1mm_down": (0., -.001, 1.),
    "5mm_out": (.005, 0., 1.),
    "quarter_pct_fast": (0., 0., 1.0025),
    "quarter_pct_slow": (0., 0., .9975),
    "half_pct_fast": (0., 0., 1.005),
    "half_pct_slow": (0., 0., .995),
    "one_pct_fast": (0., 0., 1.01),
    "one_pct_slow": (0., 0., .99),
}


def plot_window(result, path):
    ratios = sorted({r["kappa_Am2_kg"] for r in result["trajectories"]})
    launch_ids = ("one_pct_slow", "half_pct_slow", "quarter_pct_slow", "nominal",
                  "quarter_pct_fast", "half_pct_fast", "one_pct_fast", "1mm_down", "1mm_up", "5mm_out")
    labels = ("−1%", "−0.5%", "−0.25%", "Nominal", "+0.25%", "+0.5%", "+1%", "−1 mm Z", "+1 mm Z", "+5 mm R")
    counts = Counter((r["kappa_Am2_kg"], r["launch_id"]) for r in result["trajectories"] if r["outcome"] == "completed")
    values = np.array([[counts[k, name] for name in launch_ids] for k in ratios])
    fig, ax = plt.subplots(figsize=(10, 3.3), layout="constrained")
    ax.set_title("Three-lap launches after adjusting height to balance gravity", fontsize=15, weight="bold")
    ax.imshow(values, cmap="Blues", vmin=0, vmax=4, aspect="auto")
    ax.set_xticks(np.arange(len(labels)), labels)
    ax.set_yticks(np.arange(len(ratios)), [f"{k:,}" for k in ratios])
    ax.set(ylabel="Moment/mass (A·m²/kg)", xlabel="Launch error")
    for (row, col), value in np.ndenumerate(values):
        ax.text(col, row, f"{value}/4", ha="center", va="center", color="white" if value >= 3 else "#1c2533")
    fig.savefig(path, dpi=175)
    plt.close(fig)


def main():
    model = FieldMap()
    result = []
    for kappa in (2500, 3000, 10000):
        height = shifted_height(model, kappa)
        assert height is not None
        group = []
        for phase in (0, 90, 180, 270):
            for name, state in LAUNCHES.items():
                row, _ = trajectory(model, "guided_1.6kA_I", kappa, True, phase, state, 100,
                                    balanced_height=height)
                row["launch_id"] = name
                group.append(row)
        summary = Counter(r["launch_id"] for r in group if r["outcome"] == "completed")
        print(f"Gravity-balanced at kappa={kappa}: {dict(summary)}", flush=True)
        result.extend(group)
    refined = []
    for kappa in (2500, 3000, 10000):
        for name in ("1mm_up", "quarter_pct_fast", "half_pct_slow"):
            coarse = next(r for r in result if r["kappa_Am2_kg"] == kappa and r["launch_id"] == name
                          and r["phase_deg"] == 0)
            fine, _ = trajectory(model, "guided_1.6kA_I", kappa, True, 0, LAUNCHES[name], 100,
                                 steps_per_lap=576, balanced_height=coarse["reference_height_m"])
            assert (coarse["outcome"] == "completed") == (fine["outcome"] == "completed"), (coarse, fine)
            # Near a grazing exit, a small change in altitude moves the first
            # threshold crossing by several steps without changing the outcome.
            assert abs(coarse["laps"] - fine["laps"]) < .05, (coarse, fine)
            fine["launch_id"] = name
            refined.append(fine)
    destination = ROOT / "runs"
    destination.mkdir(exist_ok=True)
    output = dict(trajectories=result, half_step=refined)
    (destination / "launch_window.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    plot_window(output, destination / "launch_window.png")


if __name__ == "__main__":
    main()
