# Switched I-coils and outboard core motion in DIII-D

This replay uses the public vacuum coil geometry and the archived axisymmetric reconstruction of DIII-D shot 158103 at 3796 ms. The core is a point dipole of constant magnitude that follows the local field direction instantly. Its only device-scale parameter is the ratio of magnetic moment to mass, \(\kappa=\mu/M\), in A·m²/kg. No particular core design or attainable moment-to-mass ratio is assumed.

## Results

- With 1.6 kA independent I-coils and a modeled 100 Hz response, the phase-synchronized command delivered **0.00316 J per A·m² per lap** along the imposed ring at 10 laps per second. Tangential force was forward at every sampled angle. At 100 laps per second the work was 0.000378 J per A·m² and 67.5% of angles had forward force. The fixed-current plane did zero net work around the ring. A direct filament calculation with 96 chords per curved section agreed with the work estimates within 0.5% at the four tested lap rates for the 100 Hz response.
- With gravity and the original outboard target height, the guided 1.6 kA I-coils completed none of the 12 initial-condition tests at \(\kappa=10{,}000\). The pointwise linear-response estimate for the weakest angle requires about **17,510 A·m²/kg** to balance gravity at that fixed height. In the dedicated support sweep, 4 of 12 launches completed at 18,000, 9 of 12 at 20,000 and 12 of 12 at both 30,000 and 50,000. The linear estimate concerns vertical force at the target point. Stability and launch recovery also depend on phase, force coupling and initial conditions.
- Shifting the target height so the ambient magnetic force balances gravity sharply reduced the required coil authority. At \(\kappa=2{,}500\), the guided 1.6 kA I-coils completed the three-lap test at all four starting angles for each of the nominal launch, the two separate ±1 mm height errors, the 5 mm outward radius error and the two separate ±0.25% speed errors. The ±0.5% and ±1% speed cases stayed outside the successful launch window at this ratio. The window tests applied one error at a time. This is an unstable passive orbit, even after choosing its gravity-balanced height.
- At 2,500 A·m²/kg, the gravity-balanced height was 23.28 mm above the unshifted orbit height and the predicted circular launch speed was 62.17 m/s. The nominal and both separate ±0.25% speed-error launches completed **ten laps** at both 0° and 180°, for six of six completions. In those runs the largest radial departure was 3.98 mm and the largest vertical distance from the unshifted orbit height was 23.86 mm.
- All starts from rest left the radial corridor or otherwise missed the three-lap criterion. The successful launches began near the circular speed required for magnetic centripetal acceleration. The higher-current I+C case improved recovery at the original target height, with 7 of 12 completions at each of 3,000 and 10,000 using the optimistic supply assumption.

## Shape, core-field lift and boron coating

### Shape and opposing load

The local MHD replay uses the archived sphere and equal-volume 2:1 spheroid from the earlier shape sweep. Their center paths, speeds, magnetic forcing and times are identical. A third run with the long axis along the guide-field direction puts the elongated body broadside to the imposed motion. The force diagnostic integrates the volume-penalty reaction on the fluid. The approach metric integrates positive work up to the X-point crossing. The sphere and motion-aligned refined replays reproduce archived flux, Ohmic power and volume-mask samples. The local run uses normalized units, periodic boundaries and a stationary bulk plasma at initialization. Its force cannot be converted into a DIII-D drag load with the available inputs.

| Local MHD grid | Approach work change, long axis along motion, core only | Change with prescribed core field |
| --- | ---: | ---: |
| 48 × 40 × 40 | +0.73% | +0.28% |
| 64 × 52 × 52 | −4.64% | −5.29% |
| 80 × 64 × 64, half time step | −4.10% | −4.67% |

The two better-resolved grids give a modest work reduction for the aligned shape. The broadside geometry raises the approach work by 5.6–13.7% in the runs on the first two grids. Equal geometric volumes leave 1.3–4.5% differences in sampled mask volume on those grids. The force comparison retains sensitivity to how the numerical boundary is resolved.

The separate DIII-D orbit budget imposes an opposing toroidal force proportional to speed squared through an illustrative stationary medium. At 2,500 A·m²/kg and the gravity-balanced height, all four nominal launches pass at an opposing force per moment of **0.0002 T/m**, equivalent to 0.50 m/s² opposing acceleration. All four leave the corridor at **0.0004 T/m**, equivalently 1.0 m/s². The outcome is the same with an exact drag feedforward term or with speed feedback alone. The energy and velocity margins depend on the orientation and drive. The imposed drag sweeps do not assign a plasma drag coefficient to any geometry.

### Field generated inside the core

A controllable magnetic moment experiences force from the ambient vector-field gradient. This calculation uses \(F_i=\mathbf{m}\cdot\partial_i\mathbf{B}\) with the instantaneous moment held fixed when taking the field derivative. It includes the rotating cylindrical basis in the toroidal derivative. The torque is \(\mathbf{m}\times\mathbf{B}\). In the axisymmetric reconstruction, the axial torque and the moment of the toroidal force satisfy \(\tau_Z+R F_\phi=0\).

| Core-field command at 2,500 A·m²/kg and the unshifted orbit height | Tilt from field | Toroidal force per moment (T/m) | Torque per moment (N·m per A·m²) |
| --- | ---: | ---: | ---: |
| Direction of maximum upward force per tilt | 0.351° | −0.00406 | 0.00926 |
| Direction with zero toroidal force | 7.62° | 0 | 0.201 |

Both rows balance gravity at the reference point. The first case misses the three-lap criterion in all five launches with ideal feedback because its toroidal force exchanges orbital angular momentum with body torque. The second case completes all five launches with an 8° tilt limit and prescribed dipole direction. The simulation assumes the core can command its moment direction throughout the trajectory. It integrates the external torque so the angular-momentum requirement is visible. Body attitude, internal and external torque management, field hardware, changes to the protective field and plasma coupling remain beyond the model.

### Boron-11 shell

DIII-D experiments with enriched boron-11 powder demonstrated formation of a boron–carbon layer on graphite samples. The published proton–boron fusion measurement in the Large Helical Device used boron delivered to the plasma and a population of energetic protons. Here the hypothetical shell changes the core’s mass while its dipole moment is held fixed. The result isolates the mass penalty and leaves shell chemistry, erosion, survivability, and fusion yield unmodeled.

In the narrow 2,500 A·m²/kg launch geometry, the ambient force-balance point remains inside the same 25 mm vertical corridor with up to **7.37%** added mass. Reserving 1 mm of nominal launch height margin reduces this static threshold to **3.08%**. Added mass reduces the moment-to-mass ratio according to \(\kappa=\kappa_0/(1+M_\mathrm{shell}/M_\mathrm{bare})\). The controlled trajectory sweep allows local coil support at a target capped 1 mm below the corridor limit and adjusts launch speed for the new mass. All 12 launches at each sampled mass through **10% added mass** complete three laps. The **20% added mass** case leaves the corridor in all 12 launches. Each mass test uses four starting angles and three separate vertical launch offsets of −1, 0 and +1 mm.

## Test setup

- The outboard reference is at major radius 2.20 m. Its height is where the ambient vertical field-strength gradient vanishes, near normalized flux 0.80. The main free-flight criterion is three toroidal laps inside ±25 mm in radius and height around that reference. The endurance check extends the criterion to ten laps. The corridor is local to the reference point and a departing core is counted as a miss.
- The constrained-ring runs prescribe the coordinates and lap rate. A periodic, angle-synchronized current command aims to produce tangential force in the travel direction. A first-order hardware-response sensitivity filters each harmonic. Work per dipole moment is the integral of tangential force per moment over the ring. The ring measures available work while a separate calculation tests unconstrained motion.
- The free-flight runs integrate position and velocity in cylindrical coordinates with the full gradient of field magnitude and optional gravity. The ambient reference speed is set by the inward magnetic acceleration and the required centripetal acceleration. The guided runs use phase, position and velocity feedback. The force targets include the kinematic radial and toroidal terms. Current allocation uses the local linear response with bounded currents. Force evaluation uses the full perturbed field and its gradient.
- The main hardware case allows 1.6 kA in each of 12 independent I-coils. This is the per-coil rating in the published triple-mode configuration. The 5 kA I+C cases use 18 independently driven windings as an optimistic sensitivity. The fixed-plane case uses the previous relaxed-plane currents. The 30, 100 and 300 Hz first-order responses are modeling choices. The historical 300 Hz full-current result concerns the documented I-coil supply system and does not establish this controller's simultaneous tracking response.
- The free-flight tests cover launch position and speed errors, a start from rest, 1 g and a zero-gravity diagnostic. The gravity-balanced cases move the target height to an alternative ambient force-balance point within the same spatial corridor. They use the circular speed at that height. The phase and response tests repeat multiple launch errors at four starting angles.

The ambient nominal speed is \(v_\phi=\sqrt{-\kappa R\partial_R |B|}\). The transverse ambient stability calculation holds angular momentum fixed when perturbing the equilibrium and includes the radial derivative of the centrifugal term. An eigenvalue above zero implies exponential departure in that linearized mode. Free-flight endpoints, force budgets and modeled performance depend on the equilibrium, corridor, starting condition, assumed instantaneous alignment and choice of controller. Plasma loading and shielding, dynamic vessel screening, finite core geometry, sensing latency, and simultaneous supply behavior are outside these calculations. The replay is a numerical test. Hardware operation and confinement would require separate validation.

## Reproduce

Run these commands in the extracted directory with Python, NumPy, SciPy and Matplotlib.

```sh
OPENBLAS_NUM_THREADS=1 python3 run.py
OPENBLAS_NUM_THREADS=1 python3 margins.py
OPENBLAS_NUM_THREADS=1 python3 launch_window.py
OPENBLAS_NUM_THREADS=1 python3 endurance.py
OPENBLAS_NUM_THREADS=1 python3 verify.py
OPENBLAS_NUM_THREADS=1 python3 drag_budget.py
OPENBLAS_NUM_THREADS=1 python3 core_lift.py
OPENBLAS_NUM_THREADS=1 python3 coating_mass.py
OPENBLAS_NUM_THREADS=1 python3 local_mhd/shape_load.py
OPENBLAS_NUM_THREADS=1 python3 local_mhd/shape_load.py --fine
```

The result includes trajectory configurations, starts and outcomes in `runs/results.json`, `runs/support_margin.json`, `runs/launch_window.json` and `runs/endurance.json`. Arrays in `runs/trajectories.npz` contain time (s), major radius (m), unwrapped toroidal angle (rad), height (m), and radial, toroidal and vertical velocity divided by \(\sqrt{\kappa}\), in that order. `runs/orbit_screen.png` plots the ring work and example free-flight runs at the original height. `runs/launch_window.png` summarizes the four starting angles after the change in altitude. `runs/verification.json` records direct-filament ring calculations, static energy diagnostics, and 24 trajectory outcomes checked on a finer field grid and a smaller time step. Additional half-step checks are stored with the launch and support results.

`runs/drag_budget.json`, `runs/core_lift.json`, `runs/coating_mass.json` and `runs/shape_load*.json` contain the additional load, steering and shell tests. The four archived MHD traces used as replay checks are in `local_mhd/reference/`.

## Sources

- [Archived DIII-D G-EQDSK input](https://github.com/CaMaLabs/Fusion_Blanket_Design_TCT/blob/e49821e0b1df696d45c739f2f1915f4ef8ceba90/validation_inputs/machine_equilibria/diii_d/efit/g158103.03796)
- [Public MAFOT coil model](https://github.com/ORNL-Fusion/MAFOT/tree/7fee4ba4269a614db44b7fdd7d10356f43647b34/src/libtrip3d)
- [DIII-D I-coil power supply and patch panel report](https://fusion.gat.com/pubs-ext/SOFT04/A24803.pdf)
- [DIII-D C-coil hardware report](https://fusion.gat.com/pubs-ext/IEEE95/A22223.pdf)
- [Archived fixed-path probe shape sweep](https://chatgpt.com/library?file_id=libfile_74812b0e5080819180f5def1d2a74f63&account_id=personal)
- [Force and torque on a magnetic dipole](https://www2.physics.ox.ac.uk/sites/default/files/profiles/terquem/em-lecturenotes-45580.pdf)
- [Boron-11 powder wall conditioning in DIII-D](https://doi.org/10.1088/1741-4326/abaf31)
- [Proton–boron-11 fusion measurements on the Large Helical Device](https://www.nature.com/articles/s41467-023-36655-1)
