"""Extend representative near-balanced launches to ten laps."""

import json

from fields import FieldMap, ROOT
from launch_window import LAUNCHES
from orbit import trajectory
from run import shifted_height


def main():
    model = FieldMap()
    kappa = 2500
    height = shifted_height(model, kappa)
    results = []
    for phase in (0, 180):
        for launch in ("nominal", "quarter_pct_slow", "quarter_pct_fast"):
            row, _ = trajectory(model, "guided_1.6kA_I", kappa, True, phase, LAUNCHES[launch], 100,
                                balanced_height=height, laps=10)
            row["launch_id"] = launch
            results.append(row)
            print(f"Phase {phase}, {launch}: {row['outcome']} at {row['laps']:.3f} laps", flush=True)
    destination = ROOT / "runs"
    destination.mkdir(exist_ok=True)
    (destination / "endurance.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
